$(document).ready(function () {

    var isRtl = false;
    if ($('body').hasClass('rtl')) {
        isRtl = true;
    }

    if ((navigator.userAgent.match(/msie/i) || navigator.userAgent.match(/trident/i)) && $(window).width() < 540 ) {
        $('.carousel-container .slider').slick(
		    {
		        dots: true,
		        autoplay: false,
		        infinite: true,
		        rtl: isRtl
		    }
	    );
    } else {
        $('.carousel-container .slider').slick(
		    {
		        dots: true,
		        autoplay: true,
		        infinite: true,
		        rtl: isRtl
		    }
	    );
    }
    //$("#Hero-carousel").attr("role", "region");
    $(".carousel-container .carousel-item").show();
    if ($(window).width() <= 540) {

    }
    //focus on pause the carousel
    $("#Hero-carousel").on('keyup', function (e) {
        //console.log(e.keyCode);
        console.log($($('.carousel-container')[0]).find(':focus'));
        var focuses = $($('.carousel-container')[0]).find(':focus').length;
        if (focuses > 0) {
            //console.log("pause");
            $(".carousel-container .slider").slick('slickPause'); // start auto play
        } else {
            //console.log("play");
            $(".carousel-container .slider").slick('slickPlay'); // start auto play
        }
    });

    $("#scroll-1").on('keyup', function (e) {
        //console.log(e.keyCode);
        //console.log($($('#scroll-1')[0]).find(":focus"));
    });
    /* WI 59085: Home page Hero : carousal copy Truncation in tablet view ports 540 view */
    if ($(window).width() >= 523 && $(window).width() < 580) {
        $('.carousel-text').parent().removeClass('s-col-9-24').addClass('s-col-12-24');
        $('#carousel-text-1').parent().removeClass('s-col-9-24 s-col-12-24').addClass('s-col-18-24');
    }
    if ($(window).width() >= 580 && $(window).width() <= 767) {
        $('.carousel-text').parent().removeClass('s-col-12-24').addClass('s-col-9-24');
        $('#carousel-text-1').parent().removeClass('s-col-18-24 s-col-9-24').addClass('s-col-12-24');
    }
    $(window).resize(function () {
        if ($(window).width() >= 523 && $(window).width() < 580) {
            $('.carousel-text').parent().removeClass('s-col-9-24').addClass('s-col-12-24');
            $('#carousel-text-1').parent().removeClass('s-col-9-24 s-col-12-24').addClass('s-col-18-24');
        }
        if ($(window).width() >= 580 && $(window).width() <= 767) {
            $('.carousel-text').parent().removeClass('s-col-12-24').addClass('s-col-9-24');
            $('#carousel-text-1').parent().removeClass('s-col-18-24 s-col-9-24').addClass('s-col-12-24');
        }
    });
    adjustMobileHeight();
});

function adjustMobileHeight() {
    if ($(window).width() < 768) {
        var maxHeight = 0;
        $(".carousel-item > .ms-grid").each(function () {
            var currHeight = $(this).children().height();
            maxHeight = Math.max(maxHeight, currHeight);
        });
        $(".carousel-item > .ms-grid").each(function () {
            $(this).height(maxHeight);
            //console.log(maxHeight);
        });
    } else {
        $(".carousel-item > .ms-grid").each(function () {
            $(this).height("auto");
        });
    }
}

var swapBlueButtonToWhite = function (isMobile) {
    if (!isMobile) {
        $('#carousel-text-1 .hero-button-1').removeClass("blue-bgc")
                                            .addClass("white-bgc")
                                            .addClass("blue-c");
    }
    else {
        $('#carousel-text-1 .hero-button-1').addClass("blue-bgc")
                                            .removeClass("white-bgc")
                                            .removeClass("blue-c");
    }
}

$(window).resize(function () {
    //console.log("resize");
    setTimeout(function () {
        placeMobileHeroDotsArrows();
    }, 500);
    
    var windowWidth = 768;

    if ($.browser.chrome) {
        windowWidth = 751;
    }
    swapBlueButtonToWhite($(window).width() < windowWidth);
    setTimeout(function () {
        adjustMobileHeight();
    }, 100);
    
});

$(window).on("orientationchange", function (event) {
    console.log("orientationchange");
    placeMobileHeroDotsArrows();
    adjustMobileHeight();
});

$(window).load(function(){
    placeMobileHeroDotsArrows();
});

var placeMobileHeroDotsArrows = function () {
    var next = $('.home-hero .slick-next');
    var prev = $('.home-hero .slick-prev');
    var windowWidth = 768;

    if ($.browser.chrome) {
        windowWidth = 751;
    }

    if ($(window).width() < windowWidth) { // mobile viewport
        var heroImgHeight = $('.rtm-image-container').first().height();  //get a hero image
        $('.home-hero .slick-dots').css('top', heroImgHeight + 'px'); // place at the perfect spot, below the img

        //Adjust the arrows to be perfectly centered
        
        next.css('top', (heroImgHeight / 2 - next.height() / 2) + 'px');
        prev.css('top', (heroImgHeight / 2 - prev.height() / 2) + 'px');
        swapBlueButtonToWhite(true);
    }
    else {
        $('.home-hero .slick-dots').css('top', "");
        next.css('top', "");
        prev.css('top', "");
        swapBlueButtonToWhite(false);
    }
};

/* changes the button on the blue image to an white button*/
$(document).ready(function () {
    var windowWidth = 540;

    if ($.browser.chrome) {
        windowWidth = 523;
    }
    swapBlueButtonToWhite($(window).width() < windowWidth)
});