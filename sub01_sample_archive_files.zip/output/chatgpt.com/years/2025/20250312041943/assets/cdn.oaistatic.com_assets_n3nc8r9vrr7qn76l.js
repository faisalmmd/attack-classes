import{f7 as n}from"./wssk4we8asgvd6pj.js";import"./oupo5c2z23o60fib.js";async function e(){return null}const i=n(function(){return null});export{e as clientLoader,i as default};
//# sourceMappingURL=n3nc8r9vrr7qn76l.js.map
