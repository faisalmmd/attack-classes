import{Z as n,c as o}from"./2340486e-jrd7v1s3xt9u9uwk.js";function r(){return null}const i=n(function(){"use forget";return o.c(1),null});export{r as clientLoader,i as default};
//# sourceMappingURL=1ca89623-lyfh21b9fcb65zg9.js.map
