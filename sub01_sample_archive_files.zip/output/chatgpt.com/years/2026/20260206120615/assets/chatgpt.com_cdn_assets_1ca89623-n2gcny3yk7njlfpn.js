import{Z as n,c as o}from"./2340486e-oi6njr03ywwxfryx.js";function r(){return null}const i=n(function(){"use forget";return o.c(1),null});export{r as clientLoader,i as default};
//# sourceMappingURL=1ca89623-n2gcny3yk7njlfpn.js.map
